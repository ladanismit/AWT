function head(){
    var col = document.getElementById("demo");
    col.style.color="blue";
}

function btnclick1(){
    var pmt = prompt("Enter the color : ");
    document.getElementById("box1").style.backgroundColor=pmt;
}

function btnclick2(){
    var con = confirm("Do you want to change the color ?");
    if (con==true) {
        document.getElementById("box2").style.backgroundColor="yellow";
    }
    else{
        alert("Color not changed");
    }
}


function btnclick3(){
    document.getElementById("box3").style.backgroundColor="green";
    alert("Color Changed Successfully");
}