$(document).ready(function(){
    $("#educate").click(function(){
        $("#collegedetails").hide();
        $("#higherclass").hide();
        $("#collegedetails").slideDown(2000);
        $("#higherclass").slideDown(2000);
      });

    $('#training').click(function(){
        $(".train1").hide();
        $(".train2").hide();
        $(".train3").hide();
        $(".train1").show(2000);
        $(".train2").show(2000);
        $(".train3").show(2000);
    })
    
    $('#intern').click(function(){
        $('#intern1').hide();
        $('#intern2').hide();
        $('#intern3').hide();
        $('#intern1').slideDown(1000);
        $('#intern2').slideDown(1000);
        $('#intern3').slideDown(1000);
    })

    $('#other').click(function(){
        $('.details').hide();
        $('.details').fadeIn(3000)
    })

    $('#skills').click(function(){
        $('#list').hide();
        $('#list').fadeIn(2000);
    })
})