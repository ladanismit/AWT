$('.btn').click(function(){
    let con = confirm("Do you want to hide the box ?");
    if (con==true) {
        $('.container').hide(2000);
    }
    else{
        alert("Box is not hidden")
    }
})
    

$('.btnbtn').click(function(){
    let con = confirm("Do you want to see the box ?")
    if (con==true) {
        $('.container').show(2000);
    }
    else{
        alert("Enable to display the box")
    }
})


$('#btnplus').click(function(){
    var size = parseInt($('.container').css("height"))
    if (size<=800) {
        size+=10
        $('.container').css("height",size)
        $('.container').css("width",size)
    }else{
        alert("Box size limit achived")
    }
})


$('#btnminus').click(function(){
    var size = parseInt($('.container').css("height"))
    if (size>=100) {
        size-=10
        $('.container').css("height",size)
        $('.container').css("width",size)
    }
    else{
        alert("Box size limit exceed")
    }
})