function apple(){
    document.getElementById("appleimg").src = "eagle.jpg";
    document.getElementById("applespan").innerHTML = "This is EAGLE image"
}

function eagle(){
    document.getElementById("eagleimg").src = "tree.jpg";
    document.getElementById("eaglespan").innerHTML = "This is TREE image"
}

function tree(){
    document.getElementById("treeimg").src = "apple.jpg";
    document.getElementById("treespan").innerHTML = "This is APPLE image"
}

function tspan(){
    document.getElementById("treespan").innerHTML = "This is TREE image"
}

function aspan(){
    document.getElementById("applespan").innerHTML = "This is APPLE image"
}

function espan(){
    document.getElementById("eaglespan").innerHTML = "This is EAGLE image"
}